// Mid-Term Exam
// Grading System
// Kaili Lu
// Last Modified 7-17-13

#include <iostream>
#include <string>
using namespace std;

void main(){
	double weight = 100, student, score, total = 0;
	int i, j, k, temp;
	string name;
	char junk;

	cout << "\n\t\tMidterm Programming Part" 
		 << "\n\t\t    Grading Program"      
		 << "\n\t\t      by Kaili Lu\n\n";   
	//---------------------Banner Above----------------------------
	cout << "How many students are in this class? ";
	while (!(cin >> student)){
		cout << "No letters please! Try again: ";
		cin.clear();   cin.ignore(80, '\n');
	}
	//----------------Ask For Number of Students Above-------------
	for ( i = 1; i <= int(student);) {
		while ( i <= student){
			cout << endl << "Grade are as follows:"
				 << endl << "\t(93, 100] => A"
				 << endl << "\t(83,  93] => B"
				 << endl << "\t(73,  83] => C"
				 << endl << "\t(63,  73] => D"
				 << endl << "\t[ 0,  63] => F" << endl << endl;
			//---------------Show How Score Consist Above-------------------
			cout << "What is the NAME of student #" << i 
				 << " [may contain spaces, skip initial white space]: ";
			cin  >> junk;   cin.putback(junk);
			getline( cin, name );
			//----------------Ask For Student's Name Above------------------
			for ( j = 1, k = total = temp = 0, weight = 100; temp < 100; j++ ){
				cout << endl << "What is the NUMERIC GRADE for " << name << "\'s exam #" << j << ": ";
				cin  >> score;   cin.ignore(80, '\n');

				while ( score != int (score) || score < 0 || score > 100){
					if ( score != int (score) )
						cout << "\tSocre must be a WHOLE number. Try again: ";
					else 
						cout << "\tScore must between 0 and 100. Try again: ";
					cin >> score;   cin.ignore(80, '\n');
				}
				//----------------Ask For Score Above------------------
				cout << endl << "What is the WEIGHT of this exam? [ex. 25%]: "
					<< endl << "\t(" << weight << "% currently unaccounted for) ";
				cin  >> k;   cin.ignore(80, '\n');

				while ( k != int (k) || k < 1 || k > weight){
					if ( k != int (k) )
						cout << "\tWeight must be a WHOLE number. Try again: ";
					else 
						cout << "\tScore must between 1 and " << weight << ". Try again: ";
					cin >> k;   cin.ignore(80, '\n');
				}
				temp += k;
				weight = 100 - temp;
				//----------------Ask For Weight Above------------------
				total += score * k/100;
			}
			cout << endl << name << " got " << total << " points,"
				<< endl << "\tthus course letter grade is: ";

			switch ( int (ceil(total)-4) / 10 ){
			case 9 : cout << "A.\n"; break;
			case 8 : cout << "B.\n"; break;
			case 7 : cout << "C.\n"; break;
			case 6 : cout << "D.\n"; break;
			default : cout << "F.\n";
			}
			i++;
			system("pause"); system("cls");
		}
	}
	system("cls");
	cout << "\nThank you for using our program\n"
		 << "\tHit ENTER to terminate";
	cin.get();
}
